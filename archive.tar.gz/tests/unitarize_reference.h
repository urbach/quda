#ifndef __UNITARIZE_REFERENCE_H__
#define __UNITARIZE_REFERENCE_H__

#ifdef __cplusplus
extern "C"{
#endif
  void unitarize_reference(void *fatlink, void *ulink, QudaPrecision prec);
#ifdef __cplusplus
}
#endif

#endif
